package com.alarm.mediaplay

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Alarm(
    var id: Int = 0,
    var h: Int = 8,
    var m: Int = 0,
    var uri: String = "",
    var name: String = "",
    var yt: String = "",
    var vol: Int = 100,
    var rep: Int = 1,
    var on: Boolean = false
)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("alarms", 0)

    fun load(c: Context): MutableList<Alarm> {
        val out = ArrayList<Alarm>()
        try {
            val arr = JSONArray(prefs(c).getString("list", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Alarm(
                        o.getInt("id"), o.optInt("h", 8), o.optInt("m", 0),
                        o.optString("uri", ""), o.optString("name", ""), o.optString("yt", ""),
                        o.optInt("vol", 100), o.optInt("rep", 1), o.optBoolean("on", false)
                    )
                )
            }
        } catch (_: Exception) {}
        return out
    }

    fun save(c: Context, list: List<Alarm>) {
        val arr = JSONArray()
        for (a in list) {
            arr.put(
                JSONObject().put("id", a.id).put("h", a.h).put("m", a.m)
                    .put("uri", a.uri).put("name", a.name).put("yt", a.yt)
                    .put("vol", a.vol).put("rep", a.rep).put("on", a.on)
            )
        }
        prefs(c).edit().putString("list", arr.toString()).apply()
    }

    fun newId(c: Context): Int {
        val p = prefs(c)
        val n = p.getInt("next", 1)
        p.edit().putInt("next", n + 1).apply()
        return n
    }

    fun get(c: Context, id: Int): Alarm? = load(c).firstOrNull { it.id == id }

    fun update(c: Context, a: Alarm) {
        val l = load(c)
        val i = l.indexOfFirst { it.id == a.id }
        if (i >= 0) l[i] = a else l.add(a)
        save(c, l)
    }

    fun remove(c: Context, id: Int) {
        save(c, load(c).filter { it.id != id })
    }
}

object Sched {
    private fun pi(c: Context, id: Int) = PendingIntent.getBroadcast(
        c, id, Intent(c, AlarmReceiver::class.java).setAction("FIRE").putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun nextTime(a: Alarm): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, a.h)
            set(Calendar.MINUTE, a.m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    fun set(c: Context, a: Alarm) {
        c.getSystemService(AlarmManager::class.java)
            .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextTime(a), pi(c, a.id))
    }

    fun cancel(c: Context, id: Int) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, id))
    }

    fun restoreAll(c: Context) {
        for (a in Store.load(c)) {
            if (a.on) set(c, a)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            try { Sched.restoreAll(c) } catch (_: Exception) {}
            return
        }
        val id = i.getIntExtra("id", -1)
        val a = Store.get(c, id) ?: return
        a.on = false
        Store.update(c, a)
        c.startForegroundService(Intent(c, PlayService::class.java).putExtra("id", id))
    }
}
