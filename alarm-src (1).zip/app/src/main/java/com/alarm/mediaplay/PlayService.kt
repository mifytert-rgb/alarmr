package com.alarm.mediaplay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView

class PlayService : Service() {
    private var mp: MediaPlayer? = null
    private var web: WebView? = null
    private var wl: PowerManager.WakeLock? = null
    private var left = 1
    private var inf = false
    private val h = Handler(Looper.getMainLooper())
    private lateinit var am: AudioManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { done(); return START_NOT_STICKY }
        startForeground(1, notif())
        val a = Store.get(this, i?.getIntExtra("id", -1) ?: -1)
        if (a == null) { done(); return START_NOT_STICKY }

        // якщо щось уже грало — зупиняємо, грає той, що спрацював останнім
        releasePlayers()

        am = getSystemService(AudioManager::class.java)
        inf = a.rep == 0
        left = a.rep

        // виставляємо потрібну гучність (навіть якщо було 0)
        try {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * a.vol / 100f), 0)
        } catch (_: Exception) {}

        wl = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alarmplay:wl").apply { acquire(12 * 60 * 60 * 1000L) }
        @Suppress("DEPRECATION")
        am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)

        try {
            if (a.yt.isNotBlank()) playYoutube(a.yt) else playFile(a.uri)
        } catch (e: Exception) { done() }
        return START_NOT_STICKY
    }

    private fun playFile(u: String) {
        if (u.isBlank()) { done(); return }
        mp = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            setWakeMode(this@PlayService, PowerManager.PARTIAL_WAKE_LOCK)
            setDataSource(this@PlayService, Uri.parse(u))
            isLooping = inf
            setOnPreparedListener { it.start() }
            setOnCompletionListener {
                if (!inf) {
                    left--
                    if (left > 0) { it.seekTo(0); it.start() } else done()
                }
            }
            setOnErrorListener { _, _, _ -> done(); true }
            prepareAsync()
        }
    }

    private fun playYoutube(link: String) {
        val id = Regex("""(?:v=|youtu\.be/|shorts/|embed/|live/)([A-Za-z0-9_-]{11})""")
            .find(link)?.groupValues?.get(1)
        if (id == null) { done(); return }
        val html = """<html><body style="margin:0"><div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script><script>
var pl;function onYouTubeIframeAPIReady(){pl=new YT.Player('p',{height:'200',width:'320',videoId:'$id',
playerVars:{autoplay:1,playsinline:1},events:{
onReady:function(e){e.target.setVolume(100);e.target.playVideo()},
onStateChange:function(e){if(e.data===0)A.ended()},
onError:function(e){A.err()}}})}
</script></body></html>"""
        web = WebView(applicationContext).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webChromeClient = WebChromeClient()
            addJavascriptInterface(Bridge(), "A")
            loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
            onResume()
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun ended() {
            h.post {
                var again = inf
                if (!inf) { left--; again = left > 0 }
                if (again) web?.evaluateJavascript("pl.seekTo(0);pl.playVideo()", null) else done()
            }
        }

        @JavascriptInterface
        fun err() { h.post { done() } }
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("p", "Відтворення", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, PlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        return Notification.Builder(this, "p")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Відтворення")
            .setVisibility(Notification.VISIBILITY_SECRET)
            .addAction(0, "Стоп", stop)
            .build()
    }

    private fun releasePlayers() {
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        try { web?.destroy() } catch (_: Exception) {}
        web = null
        if (wl?.isHeld == true) wl?.release()
        wl = null
    }

    // кінець: зупинити все і виставити гучність 0
    private fun done() {
        releasePlayers()
        try {
            if (!::am.isInitialized) am = getSystemService(AudioManager::class.java)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        } catch (_: Exception) {}
        stopForeground(true)
        stopSelf()
    }
}
