package com.alarm.mediaplay

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    // будильник, який зараз редагується (null — показано список)
    private var ed: Alarm? = null
    private var fileTxt: TextView? = null
    private var ytEdit: EditText? = null

    private val accent = 0xFF4F6BFF.toInt()
    private val bgc = 0xFFF4F6FB.toInt()
    private val ink = 0xFF1B2030.toInt()
    private val gray = 0xFF7A8296.toInt()
    private val soft = 0xFFEDF0F8.toInt()
    private val green = 0xFF1E9E5A.toInt()
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun two(n: Int) = n.toString().padStart(2, '0')
    private fun shape(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    private fun small(t: String) = TextView(this).apply { text = t; textSize = 13f; setTextColor(gray) }

    private fun card(parent: LinearLayout, build: LinearLayout.() -> Unit) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(0xFFFFFFFF.toInt(), 22)
            elevation = dp(2).toFloat()
            setPadding(dp(18), dp(16), dp(18), dp(18))
            build()
        }
        parent.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })
    }

    private fun btn(t: String, fill: Int, txt: Int, h: Int = 52) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(txt)
        background = shape(fill, 16)
        stateListAnimator = null
        minHeight = 0
        minimumHeight = 0
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(h))
    }

    private fun title(t: String) = TextView(this).apply {
        text = t; textSize = 30f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink)
    }

    private fun newColumn() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(24), dp(18), dp(32))
    }

    private fun show(col: LinearLayout) {
        setContentView(ScrollView(this).apply { setBackgroundColor(bgc); addView(col) })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        window.statusBarColor = bgc
        window.navigationBarColor = bgc
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        showList()
    }

    override fun onResume() {
        super.onResume()
        if (ed == null) showList()
    }

    override fun onBackPressed() {
        if (ed != null) showList() else super.onBackPressed()
    }

    private fun reload() {
        window.decorView.post { showList() }
    }

    // ---------- допоміжне ----------

    private fun srcName(a: Alarm): String = when {
        a.yt.isNotBlank() -> "YouTube: " + a.yt
        a.name.isNotBlank() -> a.name
        else -> "джерело не вибрано"
    }

    private fun whenText(a: Alarm): String {
        val t = Sched.nextTime(a)
        val c = Calendar.getInstance().apply { timeInMillis = t }
        val today = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val day = if (c.get(Calendar.DAY_OF_YEAR) == today) "сьогодні" else "завтра"
        val mins = ((t - System.currentTimeMillis()) / 60000).toInt().coerceAtLeast(0)
        val left = if (mins >= 60) "${mins / 60} год ${mins % 60} хв" else "$mins хв"
        return "$day о ${two(a.h)}:${two(a.m)} (через $left)"
    }

    private fun ensurePerms(): Boolean {
        val am = getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            Toast.makeText(this, "Дозволь точні будильники для цього додатку, потім увімкни будильник", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return false
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (_: Exception) {}
        }
        return true
    }

    private fun toggle(a: Alarm, on: Boolean) {
        if (!on) {
            a.on = false
            Store.update(this, a)
            Sched.cancel(this, a.id)
            reload()
            return
        }
        if (a.yt.isBlank() && a.uri.isBlank()) {
            Toast.makeText(this, "Спочатку вибери файл або встав посилання", Toast.LENGTH_LONG).show()
            window.decorView.post { showEditor(a.copy(), false) }
            return
        }
        if (!ensurePerms()) { reload(); return }
        a.on = true
        Store.update(this, a)
        Sched.set(this, a)
        reload()
    }

    // ---------- екран зі списком ----------

    private fun showList() {
        ed = null
        fileTxt = null
        ytEdit = null
        val list = Store.load(this).sortedWith(compareBy({ it.h }, { it.m }))
        val col = newColumn()
        col.addView(title("Таймер звуку"))

        val active = list.filter { it.on }
        val summary = TextView(this).apply { textSize = 15f; setPadding(0, dp(6), 0, 0) }
        if (active.isEmpty()) {
            summary.text = "○ Нічого не заплановано"
            summary.setTextColor(gray)
        } else {
            val nxt = active.minByOrNull { Sched.nextTime(it) }!!
            summary.text = "● Заплановано: ${active.size}. Найближчий — ${whenText(nxt)}"
            summary.setTextColor(green)
        }
        col.addView(summary)

        if (list.isEmpty()) {
            card(col) {
                addView(small("Поки що немає жодного будильника.\nНатисни «Додати будильник» внизу."))
            }
        }

        for (a in list) {
            card(col) {
                val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
                val left = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                left.addView(TextView(this@MainActivity).apply {
                    text = "${two(a.h)}:${two(a.m)}"
                    textSize = 40f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (a.on) accent else gray)
                })
                left.addView(TextView(this@MainActivity).apply {
                    text = srcName(a)
                    textSize = 14f
                    setTextColor(ink)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
                left.addView(TextView(this@MainActivity).apply {
                    textSize = 13f
                    setPadding(0, dp(4), 0, 0)
                    if (a.on) {
                        text = "● Заплановано: " + whenText(a)
                        setTextColor(green)
                    } else {
                        text = "○ Вимкнено"
                        setTextColor(gray)
                    }
                })
                row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
                val sw = Switch(this@MainActivity)
                sw.isChecked = a.on
                sw.setOnCheckedChangeListener { _, on -> toggle(a, on) }
                row.addView(sw)
                addView(row)
                setOnClickListener { showEditor(a.copy(), false) }
            }
        }

        val add = btn("+ Додати будильник", accent, 0xFFFFFFFF.toInt(), 56)
        add.setOnClickListener { showEditor(Alarm(), true) }
        col.addView(add, LinearLayout.LayoutParams(MATCH, dp(56)).apply { topMargin = dp(22) })

        val stop = btn("Зупинити звук", 0xFFFFE9EC.toInt(), 0xFFD6334B.toInt(), 52)
        stop.setOnClickListener {
            startService(Intent(this, PlayService::class.java).setAction("STOP"))
        }
        col.addView(stop, LinearLayout.LayoutParams(MATCH, dp(52)).apply { topMargin = dp(10) })

        show(col)
    }

    // ---------- екран редагування ----------

    private fun showEditor(a: Alarm, isNew: Boolean) {
        ed = a
        val col = newColumn()
        col.addView(TextView(this).apply {
            text = "← Назад"; textSize = 16f; setTextColor(accent); setPadding(0, 0, 0, dp(8))
            setOnClickListener { showList() }
        })
        col.addView(title(if (isNew) "Новий будильник" else "Редагування"))

        // Час
        card(col) {
            addView(small("Час спрацювання"))
            val t = TextView(this@MainActivity).apply {
                textSize = 60f; typeface = Typeface.DEFAULT_BOLD; setTextColor(accent)
                text = "${two(a.h)}:${two(a.m)}"
            }
            t.setOnClickListener {
                TimePickerDialog(this@MainActivity, { _, h, m ->
                    a.h = h
                    a.m = m
                    t.text = "${two(h)}:${two(m)}"
                }, a.h, a.m, true).show()
            }
            addView(t)
            addView(small("натисни на час, щоб змінити"))
        }

        // Джерело
        card(col) {
            addView(small("Що грати"))
            val ft = TextView(this@MainActivity).apply {
                textSize = 15f; setTextColor(ink); setPadding(0, dp(6), 0, dp(10))
                text = if (a.name.isBlank()) "файл не вибрано" else a.name
            }
            fileTxt = ft
            addView(ft)
            val pick = btn("Вибрати файл  (mp3 / mp4)", soft, accent, 48)
            pick.setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*"))
                    addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, 1)
            }
            addView(pick)
            addView(small("або посилання YouTube (воно в пріоритеті)").apply { setPadding(0, dp(14), 0, dp(6)) })
            val y = EditText(this@MainActivity).apply {
                hint = "https://youtu.be/..."
                setHintTextColor(gray); setTextColor(ink); textSize = 15f
                setSingleLine()
                background = shape(soft, 14)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setText(a.yt)
            }
            ytEdit = y
            addView(y)
        }

        // Гучність
        card(col) {
            val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(small("Гучність").apply { layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) })
            val vt = TextView(this@MainActivity).apply {
                textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); text = "${a.vol}%"
            }
            row.addView(vt)
            addView(row)
            addView(SeekBar(this@MainActivity).apply {
                max = 100
                progress = a.vol
                progressTintList = ColorStateList.valueOf(accent)
                thumbTintList = ColorStateList.valueOf(accent)
                progressBackgroundTintList = ColorStateList.valueOf(soft)
                setPadding(dp(4), dp(14), dp(4), dp(4))
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, v: Int, u: Boolean) {
                        a.vol = v
                        vt.text = "$v%"
                    }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            })
        }

        // Повтори
        val chips = ArrayList<TextView>()
        var sel = if (a.rep == 0) 3 else a.rep - 1
        fun paint() {
            chips.forEachIndexed { i, c ->
                val on = i == sel
                c.background = shape(if (on) accent else soft, 14)
                c.setTextColor(if (on) 0xFFFFFFFF.toInt() else ink)
            }
        }
        card(col) {
            addView(small("Скільки разів грати"))
            val row = LinearLayout(this@MainActivity).apply { setPadding(0, dp(10), 0, 0) }
            listOf("1", "2", "3", "∞").forEachIndexed { i, t ->
                val c = TextView(this@MainActivity).apply {
                    text = t; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                    setOnClickListener {
                        sel = i
                        a.rep = if (i == 3) 0 else i + 1
                        paint()
                    }
                }
                chips.add(c)
                row.addView(c, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    if (i > 0) leftMargin = dp(8)
                })
            }
            addView(row)
            addView(small("∞ — грає безкінечно, поки не вимкнеш").apply { setPadding(0, dp(8), 0, 0) })
        }
        paint()

        // Кнопки
        val go = btn("Зберегти і запланувати", accent, 0xFFFFFFFF.toInt(), 56)
        go.setOnClickListener {
            a.yt = ytEdit?.text?.toString()?.trim() ?: ""
            if (a.yt.isBlank() && a.uri.isBlank()) {
                Toast.makeText(this, "Вибери файл або встав посилання", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (isNew && a.id == 0) a.id = Store.newId(this)
            val ok = ensurePerms()
            a.on = ok
            Store.update(this, a)
            if (ok) Sched.set(this, a) else Sched.cancel(this, a.id)
            showList()
        }
        col.addView(go, LinearLayout.LayoutParams(MATCH, dp(56)).apply { topMargin = dp(22) })

        if (!isNew) {
            val del = btn("Видалити будильник", 0xFFFFE9EC.toInt(), 0xFFD6334B.toInt(), 52)
            del.setOnClickListener {
                Sched.cancel(this, a.id)
                Store.remove(this, a.id)
                showList()
            }
            col.addView(del, LinearLayout.LayoutParams(MATCH, dp(52)).apply { topMargin = dp(10) })
        }

        show(col)
    }

    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        val u = d?.data ?: return
        if (req != 1 || res != RESULT_OK) return
        val a = ed ?: return
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        var n = "файл вибрано"
        contentResolver.query(u, null, null, null, null)?.use {
            if (it.moveToFirst()) {
                val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) n = it.getString(i)
            }
        }
        a.uri = u.toString()
        a.name = n
        a.yt = ""
        fileTxt?.text = n
        ytEdit?.setText("")
    }
}
